# Trading Engine API — Starter (Fixed Layout)

This is the corrected starter with proper `/app` directory layout.
